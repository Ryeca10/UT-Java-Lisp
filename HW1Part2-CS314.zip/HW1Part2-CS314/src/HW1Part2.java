
/*
 * Raika Sanii 
 * rs47345
 * 
 * CS314 / TTH 2-2:30p
 * 
 * HW1 Part2 (Timing Program)
 * 
 * 01/23/2014
 * 
 * */



import java.math.BigInteger;


public class HW1Part2 
{
	public static void main(String args[])
	{
		Stopwatch timer = new Stopwatch();
		int n;
	///////////////////////////////////////////////////////////////	
		
		System.out.println("for Daffy:\n");
		
		for (int i = 30; i < 45 ; i++)
		{
			timer.start();
			
			timing.daffy(i);
			
			timer.stop();
			
			System.out.println(timer);
		}
		
		System.out.println("\n");
		
	 /////////////////////////////////////////////////////////////	
		
		System.out.println("for Donald:\n");
		
		for (int i = 30; i < 45 ; i++)
		{
			timer.start();
			
			timing.donald(i);
			
			timer.stop();
			
			System.out.println(timer);
		}
		
		System.out.println("\n");
		
	/////////////////////////////////////////////////////////////
	
	/// Mickey
		
		System.out.println("for Mickey:\n");
		
		for (n = 1000 ; n <= 128000 ; n *= 2)
		{
			int arr[] = timing.randomarr(n);	
			
				timer.start();
				
				timing.mickey(arr);
				
				timer.stop();
				
				System.out.println(timer);
		}
		
		System.out.println("\n");
		
		
	/// Minnie
		
			System.out.println("for Minnie:\n");
			
			for (n = 1000 ; n <= 128000 ; n *= 2)
			{
				int arr[] = timing.randomarr(n);
				
				timer.start();
				
				timing.minnie(arr);
				
				timer.stop();
				
				System.out.println(timer);
			}
			
			System.out.println("\n");
			
	/// Goofy
			
			System.out.println("for Goofy:\n");
			
			for (n = 1000 ; n <= 128000 ; n *= 2)
			{
				int arr[] = timing.randomarr(n);
				
				timer.start();
				
				timing.goofy(arr);
				
				timer.stop();
				
				System.out.println(timer);
			}
			
			System.out.println("\n");
			
	/// Pluto
			
			System.out.println("for Pluto:\n");
			
			for (n = 1000 ; n <= 128000 ; n *= 2)
			{
				int arr[] = timing.randomarr(n);
				
				timer.start();
				
				timing.pluto(arr);
				
				timer.stop();
				
				System.out.println(timer);
			}
			
			System.out.println("\n");
			
	/// Gyro
			
			System.out.println("for Gyro:\n");
			
			for (n = 1000 ; n <= 128000 ; n *= 2)
			{
				int arr[] = timing.randomarr(n);
				
			    timing.pluto(arr);
			    
				timer.start();
				
				timing.gyro(arr);
				
				timer.stop();
				
				System.out.println(timer);
			}
			
			System.out.println("\n");
			
			
	/// fact(BigInteger n)
			
			System.out.println("for Fact(BigInteger n):\n");
			
			for (int i = 1000 ; i <= 64000 ; i *= 2)
			{
				BigInteger bign = BigInteger.valueOf((long)i);
				
				timer.start();
				
				timing.fact(bign);
				
				timer.stop();
				
				System.out.println(timer);
				
			}
	}
	
	
	
}

