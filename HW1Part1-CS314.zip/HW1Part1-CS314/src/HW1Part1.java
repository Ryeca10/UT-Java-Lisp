
public class HW1Part1 
{
	public static void main (String []  args)
	{
		int i = 5;
		int mainResult;
		
		mainResult = fact(i);
		
		System.out.println(mainResult);
		
	}
	
	public static int fact(int n)
	{
		int result;
		
		if (n == 0)
			result = 1;
		else if (n >= 1 )
			result = n * fact(n-1);
		
		return result;
	}
	
}
